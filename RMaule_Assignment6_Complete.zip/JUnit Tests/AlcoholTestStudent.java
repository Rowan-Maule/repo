/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AlcoholTestStudent {
	Alcohol a1 = new Alcohol("A1", Size.LARGE, true);
	Alcohol a2 = new Alcohol("A2", Size.SMALL, false);	
	
	@Test
	void testToString() {
		assertEquals("A1,LARGE,true,3.6", a1.toString());
		assertEquals("A2,SMALL,false,2.0", a2.toString());
	}

	@Test
	void testEqualsObject() {
		assertFalse(a1.equals(a2));
		assertTrue(a1.equals(a1));
	}

	@Test
	void testCalcPrice() {
		assertEquals(3.6, a1.calcPrice());
		assertEquals(2, a2.calcPrice());
	}

	@Test
	void testAlcohol() {
		assertTrue(a1.equals(new Alcohol("A1", Size.LARGE, true)));
	}

	@Test
	void testIsWeekend() {
		assertTrue(a1.isWeekend());
		assertFalse(a2.isWeekend());
	}

}
