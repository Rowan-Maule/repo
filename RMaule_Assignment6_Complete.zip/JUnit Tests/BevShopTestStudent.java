/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BevShopTestStudent {
	BevShop b1 = new BevShop();
	
	@Test
	void testIsValidTime() {
		assertTrue(b1.isValidTime(8));
		assertFalse(b1.isValidTime(5));
	}

	@Test
	void testGetMaxNumOfFruits() {
		assertEquals(5, b1.getMaxNumOfFruits());
	}

	@Test
	void testGetMinAgeForAlcohol() {
		assertEquals(21, b1.getMinAgeForAlcohol());
	}

	@Test
	void testIsMaxFruit() {
		assertTrue(b1.isMaxFruit(6));
		assertFalse(b1.isMaxFruit(3));
	}

	@Test
	void testGetMaxOrderForAlcohol() {
		assertEquals(3, b1.getMaxOrderForAlcohol());
	}

	@Test
	void testIsEligibleForMore() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, null, 0);
		b2.getCurrentOrder().addNewBeverage(null, null);
		
		assertTrue(b2.isEligibleForMore());
	}

	@Test
	void testGetNumOfAlcoholDrink() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, null, 0);
		b2.getCurrentOrder().addNewBeverage(null, null);
		
		assertEquals(1, b2.getNumOfAlcoholDrink());
	}

	@Test
	void testIsValidAge() {
		assertTrue(b1.isValidAge(21));
	}

	@Test
	void testStartNewOrder() {
		b1.startNewOrder(8, Day.SUNDAY, "John", 21);
		assertTrue(b1.getCurrentOrder().isWeekend());
	}

	@Test
	void testProcessCoffeeOrder() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, null, 0);
		b2.processCoffeeOrder(null, null, true, false);
		
		assertEquals(1, b2.getOrderAtIndex(0).findNumOfBeveType(Type.COFFEE));
	}

	@Test
	void testProcessAlcoholOrder() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, null, 0);
		b2.processAlcoholOrder(null, null);
		
		assertEquals(1, b2.getOrderAtIndex(0).findNumOfBeveType(Type.ALCOHOL));
	}

	@Test
	void testProcessSmoothieOrder() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, null, 0);
		b2.processSmoothieOrder(null, null, 3, true);
		
		assertEquals(1, b2.getOrderAtIndex(0).findNumOfBeveType(Type.SMOOTHIE));	}

	@Test
	void testFindOrder() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, null, 0);
		b2.processSmoothieOrder(null, null, 3, true);
		
		assertEquals(0, b2.findOrder(0));
	}

	@Test
	void testTotalOrderPrice() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		b2.getCurrentOrder().addNewBeverage("smoothie", Size.LARGE, 3, true);
		
		assertEquals(6, b2.totalOrderPrice(0));
	}

	@Test
	void testTotalMonthlySale() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		b2.getCurrentOrder().addNewBeverage("smoothie", Size.LARGE, 3, true);
		
		assertEquals(6, b2.totalMonthlySale());
	}

	@Test
	void testTotalNumOfMonthlyOrders() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		b2.getCurrentOrder().addNewBeverage("smoothie", Size.LARGE, 3, true);
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);

		
		assertEquals(2, b2.totalNumOfMonthlyOrders());
	}

	@Test
	void testGetCurrentOrder() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		
		assertEquals(b2.getOrderAtIndex(0), b2.getCurrentOrder());
	}

	@Test
	void testGetOrderAtIndex() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		
		assertEquals( b2.getCurrentOrder(), b2.getOrderAtIndex(0));
	}

	@Test
	void testToString() {
		BevShop b2 = new BevShop();
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		b2.startNewOrder(0, Day.FRIDAY, "John", 21);
		b2.processAlcoholOrder(null, null);
		b2.startNewOrder(0, Day.FRIDAY, "John", 0);
		b2.getCurrentOrder().addNewBeverage("smoothie", Size.LARGE, 3, true);

		assertEquals("0,0,FRIDAY,John,0,[] , 0,0,FRIDAY,John,21,[null,null,false,3.0] , 0,0,FRIDAY,John,0,[smoothie,LARGE,true36.0] , 9.0", b2.toString());
	}

}
