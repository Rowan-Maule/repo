/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CustomerTestStudent {
	Customer cust = new Customer("J", 21);
	
	@Test
	void testCustomerStringInt() {
		assertEquals(cust.toString(), new Customer("J", 21).toString());
	}

	@Test
	void testCustomerCustomer() {
		assertEquals(cust.toString(), new Customer(cust).toString());
	}

	@Test
	void testGetAge() {
		assertEquals(21, cust.getAge());
	}

	@Test
	void testSetAge() {
		cust.setAge(20);
		assertEquals(20, cust.getAge());
	}

	@Test
	void testGetName() {
		assertEquals("J", cust.getName());
	}

	@Test
	void testSetName() {
		cust.setName("Name");
		assertEquals("Name", cust.getName());
	}

	@Test
	void testToString() {
		assertEquals("J,21", cust.toString());
	}

}
