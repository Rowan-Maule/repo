/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OrderTestStudent {
	Customer cust = new Customer("John", 21);
	Order o1 = new Order(8, Day.SUNDAY, cust);
	Order o2 = new Order(15, Day.WEDNESDAY, cust);

	@Test
	void testOrder() {		
		assertEquals(o1.getCustomer(), cust);
	}

	@Test
	void testGenerateOrder() {
		assertEquals(50000, o1.generateOrder(), 40000);
	}

	@Test
	void testGetOrderNo() {
		o1.generateOrder();
		assertEquals(50000, o1.getOrderNo(), 40000);
	}

	@Test
	void testGetOrderTime() {
		assertEquals(8, o1.getOrderTime());
	}

	@Test
	void testGetOrderDay() {
		assertEquals(Day.SUNDAY, o1.getOrderDay());
	}

	@Test
	void testGetCustomer() {
		assertEquals(cust, o1.getCustomer());
	}

	@Test
	void testIsWeekend() {
		assertTrue(o1.isWeekend());
		assertFalse(o2.isWeekend());
	}

	@Test
	void testGetBeverage() {		
		o2.addNewBeverage("A", Size.SMALL, true, true);
		
		assertEquals(new Coffee("A", Size.SMALL, true, true), o2.getBeverage(0));
	}

	@Test
	void testGetTotalItems() {
		o2.addNewBeverage("A", Size.SMALL, true, true);

		assertEquals(1, o2.getTotalItems());
	}

	@Test
	void testAddNewBeverageStringSizeBooleanBoolean() {
		o2.addNewBeverage("A", Size.SMALL, true, true);

		assertEquals(1, o2.getTotalItems());
	}

	@Test
	void testAddNewBeverageStringSize() {
		o2.addNewBeverage("A", Size.SMALL);
		
		assertEquals(1, o2.getTotalItems());

	}

	@Test
	void testAddNewBeverageStringSizeIntBoolean() {
		o2.addNewBeverage("A", Size.SMALL, 3, true);
		
		assertEquals(1, o2.getTotalItems());
	}

	@Test
	void testCalcOrderTotal() {
		o2.addNewBeverage("A", Size.SMALL, 3, true);
		
		assertEquals(5, o2.calcOrderTotal());
	}

	@Test
	void testFindNumOfBeveType() {
		o2.addNewBeverage("A", Size.SMALL, 3, true);

		assertEquals(1, o2.findNumOfBeveType(Type.SMOOTHIE));
	}

	@Test
	void testToString() {
		o2.addNewBeverage("A", Size.SMALL, 3, true);
		
		assertEquals("0,15,WEDNESDAY,John,21,[A,SMALL,true35.0]", o2.toString());
	}
}
