/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SmoothieTestStudent {
	Smoothie s1 = new Smoothie("S", Size.LARGE, 4, false);
	
	@Test
	void testToString() {
		assertEquals("S,LARGE,false45.0", s1.toString());
	}

	@Test
	void testEqualsObject() {
		assertEquals(s1, new Smoothie("S", Size.LARGE, 4, false));
	}

	@Test
	void testCalcPrice() {
		assertEquals(5, s1.calcPrice());
	}

	@Test
	void testSmoothie() {
		assertEquals(s1, new Smoothie("S", Size.LARGE, 4, false));
	}

	@Test
	void testGetNumOfFruits() {
		assertEquals(4, s1.getNumOfFruits());
	}

	@Test
	void testGetAddProtein() {
		assertFalse(s1.getAddProtein());
	}

}
