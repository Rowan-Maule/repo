/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/

import java.util.ArrayList;

public class BevShop implements BevShopInterface {
	private final int MIN_AGE_FOR_ALCOHOL = 21;  //Minimum age for offering alcohol drink
	private final int MAX_ORDER_FOR_ALCOHOL= 3;   /*Maximum number of alcohol beverages that can be ordered within an order  */
	private final int MIN_TIME= 8;				//earliest time for the order
	private final int MAX_TIME= 23;				//latest  time for the order
	private final int MAX_FRUIT = 5;
	
	public ArrayList<Order> orders = new ArrayList<>();
	
	public BevShop()
	{
		
	}

	@Override
	public boolean isValidTime(int time) {
		if(MIN_TIME <= time && time <= MAX_TIME)
		{
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int getMaxNumOfFruits() {
		return MAX_FRUIT;
	}

	@Override
	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}

	@Override
	public boolean isMaxFruit(int numOfFruits) {
		if(numOfFruits > MAX_FRUIT)
		{
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}

	@Override
	public boolean isEligibleForMore() {
		if(orders.getLast().findNumOfBeveType(Type.valueOf("ALCOHOL")) > 3)
		{
			return false;
		}
		
		return true;
	}

	@Override
	public int getNumOfAlcoholDrink() {
		return orders.getLast().findNumOfBeveType(Type.valueOf("ALCOHOL"));
	}

	@Override
	public boolean isValidAge(int age) {
		if(age < MIN_AGE_FOR_ALCOHOL)
		{
			return false;
		}
		
		return true;
	}

	@Override
	public void startNewOrder(int time, Day day, String customerName, int customerAge) {
		orders.add(new Order(time, day, new Customer(customerName, customerAge)));
	}

	@Override
	public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
		orders.getLast().addNewBeverage(bevName, size, extraShot, extraSyrup);
	}

	@Override
	public void processAlcoholOrder(String bevName, Size size) {
		orders.getLast().addNewBeverage(bevName, size);
	}

	@Override
	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) {
		orders.getLast().addNewBeverage(bevName, size, numOfFruits, addProtein);
	}

	@Override
	public int findOrder(int orderNo) {
		for(int i = 0; i < orders.size(); i++)
		{
			if(orderNo == orders.get(i).getOrderNo())
			{
				return i;
			}
		}
		return -1;
	}

	@Override
	public double totalOrderPrice(int orderNo) {
		return orders.get(orderNo).calcOrderTotal();
	}

	@Override
	public double totalMonthlySale() {
		double total = 0;
		
		for(int i = 0; i < orders.size(); i++)
		{
			total += orders.get(i).calcOrderTotal();
		}
		
		return total;
	}

	@Override
	public int totalNumOfMonthlyOrders() {
		return orders.size();
	}

	@Override
	public Order getCurrentOrder() {
		return orders.getLast();
	}

	@Override
	public Order getOrderAtIndex(int index) {
		return orders.get(index);
	}

	@Override
	public void sortOrders() {
		int l = orders.size();
		
		for(int i = 0; i < l - 1; i++)
		{
			int min_index = i;
			
			for(int o = i + 1; o < l; o++) 
			{
				if(orders.get(o).getOrderNo() < orders.get(min_index).getOrderNo()) {
					min_index = o;
				}
			}
			
			if(min_index != i)
			{
				Order x = orders.get(i);
				orders.set(i, orders.get(min_index));
				orders.set(min_index, x);
			}
		}
	}
	
	@Override
	public String toString()
	{
		String r = "";
		
		for(int i = 0; i < orders.size(); i++)
		{
			r += orders.get(i).toString() + " , ";
		}
		
		r += totalMonthlySale();

		return r;
	}
}
