/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import java.util.Scanner;

public class BevShopDriverApp {
	public static void main(String[] args) {
		BevShop b1 = new BevShop();
		boolean newOrder = false;
		
		System.out.println("You must be 21 to order alcoholic beverages, and you can only have 3 alcoholic beverages in one order.");
		Scanner in = new Scanner(System.in);
		
		do {
			System.out.println("Start a new order:");
			System.out.println("Enter your name: ");
			String name = in.nextLine();
			System.out.println("Enter your age: ");
			int age = in.nextInt();
			b1.startNewOrder(age, Day.valueOf("SUNDAY"), name, age);
			System.out.println("Your order total is: $" + b1.getOrderAtIndex(b1.orders.size() - 1).calcOrderTotal());
			
			if(age >= 21)
			{
				System.out.println("You can order alcohol.");
			} else { 
				System.out.println("You cannot order alcohol.");
			}
			
			int totalAlcohol = 0;
			boolean newDrink;
			
			do {
				newDrink = false;
				System.out.println("What size drink do you want? (SMALL, MEDIUM, LARGE)");
				String size = in.next();
				
				System.out.println("Select a drink to order: (enter 1 for COFFEE, 2 for SMOOTHIE, 3 for ALCOHOL)");
				int drinkNum = in.nextInt();
				
				switch(drinkNum)
				{
					case 1:
						System.out.println("You added COFFEE to your order.");
						System.out.println("Do you want an extra shot? (y/n)");
						String shot = in.next();
						boolean extraShot;
						if(shot.equals("y"))
						{
							extraShot = true;
						} else {
							extraShot = false;
						}
						
						System.out.println("Do you want extra syrup? (y/n)");
						String syrup = in.next();
						boolean extraSyrup;
						if(syrup.equals("y"))
						{
							extraSyrup = true;
						} else {
							extraSyrup = false;
						}
						
						b1.getOrderAtIndex(b1.orders.size() - 1).addNewBeverage("COFFEE", Size.valueOf(size), extraShot, extraSyrup);
						
						break;
					
					case 2:
						System.out.println("You added a SMOOTHIE to your order.");
						System.out.println("How many fruits do you want?");
						int fruits = in.nextInt();
						System.out.println("Do you want protein powder in your smoothie? (y/n)");
						String protein = in.next();
						boolean yesProtein;
						if(protein.equals("y"))
						{
							yesProtein = true;
						} else {
							yesProtein = false;
						}
						
						b1.getOrderAtIndex(b1.orders.size() - 1).addNewBeverage("smoothie", Size.valueOf(size), fruits, yesProtein);
						
						break;
						
					case 3:
						if(age < 21 || totalAlcohol >= 3)
						{
							System.out.println("You cannot order this!");
						} else {
							System.out.println("You added ALCOHOL to your order");
							b1.getOrderAtIndex(b1.orders.size() - 1).addNewBeverage("alcohol", Size.valueOf(size));
							totalAlcohol++;
						}
						
						break;
						
					default:
						System.out.println("Please enter a valid number!");
						newDrink = true;
						break;
				}
				if(!newDrink)
				{
					System.out.println("Your order total is: $" + b1.getOrderAtIndex(b1.orders.size() - 1).calcOrderTotal());
					System.out.println("Want to order another drink? (y/n)");
					String another = in.next();
					if(another.equals("y"))
					{
						newDrink = true;
					} else {
						newDrink = false;
					}
				}
			} while(newDrink);
			
			System.out.println("Your order total is: $" + b1.getOrderAtIndex(b1.orders.size() - 1).calcOrderTotal());
			System.out.println("You have ordered - \nCOFFEE: " + b1.getOrderAtIndex(b1.orders.size() - 1).findNumOfBeveType(Type.valueOf("COFFEE")) + 
								" \nSMOOTHIE: " + b1.getOrderAtIndex(b1.orders.size() - 1).findNumOfBeveType(Type.valueOf("SMOOTHIE")) +
								" \nALCOHOL: " + b1.getOrderAtIndex(b1.orders.size() - 1).findNumOfBeveType(Type.valueOf("ALCOHOL")));
			System.out.println("Want to make a new order? (y/n)");
			String ord = in.next();
			if(ord.equals("y"))
			{
				newOrder = true;
			} else {
				newOrder = false;
			}
			in.nextLine();
		} while(newOrder);
	}
}
