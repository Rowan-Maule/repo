/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
public class Coffee extends Beverage{
	private boolean extraShot;
	private boolean extraSyrup;
	
	public Coffee(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
		super(bevName, Type.valueOf("COFFEE"), size);
		this.extraShot = extraShot;
		this.extraSyrup = extraSyrup;
	}

	public boolean getExtraShot()
	{
		return extraShot;
	}
	
	public boolean getExtraSyrup()
	{
		return extraSyrup;
	}
	
	@Override
	public double calcPrice() {
		double price = this.addSizePrice();
		
		if(extraShot == true)
		{
			price += 0.5;
		}
		
		if(extraSyrup == true)
		{
			price += 0.5;
		}
		
		return price;
	}
	
	@Override
	public String toString()
	{
		return (this.getBevName() + "," + this.getSize() + "," + this.extraShot + "," + this.extraSyrup + "," + this.calcPrice());
	}
	
	@Override
	public boolean equals(Object anotherBev)
	{
		Coffee Temp = (Coffee)anotherBev;
		
		if(this.toString().equals(Temp.toString()))
		{
			return true;
		} else {
			return false;
		}
	}
}
