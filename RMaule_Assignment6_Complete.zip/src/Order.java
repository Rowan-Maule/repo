/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
import java.util.ArrayList;
import java.util.Random;

public class Order implements OrderInterface, Comparable<Order>{
	private int orderNumber;
	private int orderTime;
	private Day orderDay;
	private Customer cust;
	private ArrayList<Beverage> beverageList = new ArrayList<>();
	
	public Order(int orderTime, Day orderDay, Customer cust)
	{
		this.orderTime = orderTime;
		this.orderDay = orderDay;
		this.cust = cust;
	}
	
	public int generateOrder()
	{
		Random rand = new Random();
		this.orderNumber = rand.nextInt(80001) + 10000;
		
		return orderNumber;
	}
	
	public int getOrderNo()
	{
		return orderNumber;
	}
	
	public int getOrderTime()
	{
		return orderTime;
	}
	
	public Day getOrderDay()
	{
		return orderDay;
	}
	
	public Customer getCustomer()
	{
		return cust;
	}
	
	public boolean isWeekend()
	{
		if((this.orderDay.equals(Day.valueOf("SATURDAY"))) || (this.orderDay.equals(Day.valueOf("SUNDAY"))))
		{
			return true;
		} else {
			return false;
		}
	}
	
	public Beverage getBeverage(int itemNo)
	{
		if(beverageList.size() > itemNo)
		{
			return beverageList.get(itemNo);
		} else {
			return null;
		}
	}
	
	public int getTotalItems() {
		return beverageList.size();
	}
	
	
	//adds new coffee beverage
	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup)
	{
		beverageList.add(new Coffee(bevName, size, extraShot, extraSyrup));
	}
	
	//adds new alcohol beverage
	public void addNewBeverage(String bevName, Size size)
	{
		beverageList.add(new Alcohol(bevName, size, isWeekend()));
	}
	
	//adds new smoothie beverage
	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
		beverageList.add(new Smoothie(bevName, size, numOfFruits, addProtein));
	}
	
	public double calcOrderTotal()
	{
		double total = 0;
		for(int i = 0; i < beverageList.size(); i++)
		{
			total += beverageList.get(i).calcPrice();
		}
		
		return total;
	}
	
	public int findNumOfBeveType(Type type)
	{
		int num = 0;
		for(int i = 0; i < beverageList.size(); i++)
		{
			if(beverageList.get(i).getType().equals(type))
			{
				num++;
			}
		}
		
		return num;
	}
	
	@Override
	public String toString()
	{
		return orderNumber + "," + orderTime + "," + orderDay + "," + cust.toString() + "," + beverageList;
	}
	
	public int compareTo(Order anotherOrder)
	{
		return this.compareTo(anotherOrder);
	}
}
