/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
public enum Size {
	SMALL,
	MEDIUM,
	LARGE
}
