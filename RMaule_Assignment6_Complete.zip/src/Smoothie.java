/* Class: CMSC203 CRN 33083
 Program: Assignment #6
 Instructor: Khandan Monshi
 Summary of Description: Make a beverage shop that takes orders for smoothies, coffee, and alcohol.
 Due Date: 5/12/25
 Integrity Pledge: I pledge that I have completed the programming assignment independently.
 I have not copied the code from a student or any source.
Student Name: Rowan Maule
*/
public class Smoothie extends Beverage{
	private int numOfFruits;
	private boolean addProtein;
	
	public Smoothie(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
		super(bevName, Type.valueOf("SMOOTHIE"), size);
		this.numOfFruits = numOfFruits;
		this.addProtein = addProtein;
	}

	public int getNumOfFruits()
	{
		return numOfFruits;
	}
	
	public boolean getAddProtein()
	{
		return addProtein;
	}
	
	@Override
	public double calcPrice() {
		if(addProtein)
		{
			return this.addSizePrice() + (0.5 * this.numOfFruits) + 1.5;
		} else {
			return this.addSizePrice() + (0.5 * this.numOfFruits);
		}
	}
	
	@Override
	public String toString()
	{
		return this.getBevName() + "," + this.getSize() + "," + this.addProtein + this.numOfFruits + this.calcPrice();
	}
	
	@Override
	public boolean equals(Object anotherBev)
	{
		Smoothie Temp = (Smoothie)anotherBev;
		if(this.toString().equals(Temp.toString()))
		{
			return true;
		} else {
			return false;
		}
	}
}
